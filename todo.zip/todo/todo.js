var toDoEntryBox = document.getElementById("todo-entry-box");
var toDoList = document.getElementById("todo-list");
var itemtext;
function newToDoItem(itemText, completed) {
    var toDoItem = document.createElement("li");
    console.log(itemText);
    var toDoText = document.createTextNode(itemText);
    toDoItem.appendChild(toDoText);

    if (completed) {
        toDoItem.classList.add("completed");
    }

  document.getElementById("todo-list").appendChild(toDoItem);

  document.getElementById("todo-entry-box").value="";

    toDoItem.addEventListener("click", toggleToDoItemState);
    console.log(toDoItem.classList);
}

function addToDoItem() {
     itemText = document.getElementById("todo-entry-box").value;
    // console.log("aaya");
    console.log(itemText);

    newToDoItem(itemText, false);
}
function toggleToDoItemState() {
  console.log(this.innerHTML);
    if (this.classList.contains("completed")) {
        this.classList.remove("completed");
    } else {
      this.classList.add("completed");
          this.style.textDecoration="line-through";
          this.style.color="green";

    }
}
function clearCompletedToDoItems() {
    var completedItems = document.getElementById("todo-list").getElementsByClassName("completed");

    while (completedItems.length > 0) {
        completedItems.item(0).remove();
    }
}
function emptyList() {
    var toDoItems = document.getElementById("todo-list").children;
    while (toDoItems.length > 0) {
        toDoItems.item(0).remove();
    }
}
function saveList() {
    var toDos = [];


    for (var i = 0; i < document.getElementById("todo-list").children.length; i++) {
        var toDo = document.getElementById("todo-list").children.item(i);

        var toDoInfo = {
            "task": toDo.innerText,
            "completed": toDo.classList.contains("completed")
        };
        console.log(toDos);

        toDos.push(toDoInfo);

    }



    localStorage.setItem("toDos", JSON.stringify(toDos));
}
function loadList() {
    if (localStorage.getItem("toDos") != null) {
        var toDos = JSON.parse(localStorage.getItem("toDos"));

        for (var i = 0; i < toDos.length; i++) {
            var toDo = toDos[i];
            newToDoItem(toDo.task, toDo.completed);
        }
    }
}
loadList();
